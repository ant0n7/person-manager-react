# Frontend

## Setup
```bash
yarn install

yarn dev -o
```