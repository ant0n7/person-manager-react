<template>
  <div class="container">
    <h1>Welcome</h1>

    <div class="row">
      <div class="col-md-4 col-12">
        <Card
          title="Students"
          subtitle="List of Students"
          image="/student_new.png"
          link="/students"
          buttonText="Manage"
        />
      </div>
      <div class="col-md-4 col-12">
        <Card
          title="Subjects"
          subtitle="List of Subjects"
          image="/subjects_new.jpg"
          link="/subjects"
          buttonText="Manage"
        />
      </div>
      <div class="col-md-4 col-12">
        <Card
          title="Classes"
          subtitle="List of Classes"
          image="/school_new.png"
          link="/classes"
          buttonText="Manage"
        />
      </div>
    </div>
  </div>
</template>
