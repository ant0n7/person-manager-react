const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-22f3062b.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "pages/classes/[id].vue",
      "pages/classes/create.vue",
      "pages/classes/index.vue",
      "pages/index.vue",
      "pages/login.vue",
      "pages/students/[id].vue",
      "pages/students/create.vue",
      "pages/students/index.vue",
      "pages/subjects/[id].vue",
      "pages/subjects/create.vue",
      "pages/subjects/index.vue",
      "layouts/default.vue"
    ],
    "css": [
      "entry.ff01aa7f.css"
    ]
  },
  "pages/classes/[id].vue": {
    "file": "_id_-ffff0af1.mjs",
    "src": "pages/classes/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_Card-60604c66.mjs",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch-483c0c3a.mjs",
      "_cookie-4d7aea94.mjs",
      "_asyncData-6c1f0035.mjs"
    ]
  },
  "_Heading-b0b26383.mjs": {
    "file": "Heading-b0b26383.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_Card-60604c66.mjs": {
    "file": "Card-60604c66.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_fetch-483c0c3a.mjs": {
    "file": "fetch-483c0c3a.mjs",
    "imports": [
      "_asyncData-6c1f0035.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_cookie-4d7aea94.mjs": {
    "file": "cookie-4d7aea94.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_asyncData-6c1f0035.mjs": {
    "file": "asyncData-6c1f0035.mjs",
    "imports": [
      "_cookie-4d7aea94.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/classes/create.vue": {
    "file": "create-1ca1d5ea.mjs",
    "src": "pages/classes/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_index-09d79a47.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_index-09d79a47.mjs": {
    "file": "index-09d79a47.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/classes/index.vue": {
    "file": "index-4c8787a9.mjs",
    "src": "pages/classes/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_Alert-234dff9f.mjs",
      "_Card-60604c66.mjs",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-6c1f0035.mjs",
      "_cookie-4d7aea94.mjs"
    ]
  },
  "_Alert-234dff9f.mjs": {
    "file": "Alert-234dff9f.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/index.vue": {
    "file": "index-a3139a2c.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Card-60604c66.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/login.vue": {
    "file": "login-4d015bbe.mjs",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_Alert-234dff9f.mjs",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-4d7aea94.mjs",
      "_index-09d79a47.mjs"
    ]
  },
  "pages/students/[id].vue": {
    "file": "_id_-b3cdabd3.mjs",
    "src": "pages/students/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_Card-60604c66.mjs",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch-483c0c3a.mjs",
      "_cookie-4d7aea94.mjs",
      "_index-09d79a47.mjs",
      "_asyncData-6c1f0035.mjs"
    ]
  },
  "pages/students/create.vue": {
    "file": "create-4a4be7b9.mjs",
    "src": "pages/students/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_index-09d79a47.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/students/index.vue": {
    "file": "index-6791cb7a.mjs",
    "src": "pages/students/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_Alert-234dff9f.mjs",
      "_Card-60604c66.mjs",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-6c1f0035.mjs",
      "_cookie-4d7aea94.mjs"
    ]
  },
  "pages/subjects/[id].vue": {
    "file": "_id_-4db8bf22.mjs",
    "src": "pages/subjects/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_Card-60604c66.mjs",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_fetch-483c0c3a.mjs",
      "_cookie-4d7aea94.mjs",
      "_asyncData-6c1f0035.mjs"
    ]
  },
  "pages/subjects/create.vue": {
    "file": "create-9a7a8100.mjs",
    "src": "pages/subjects/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_index-09d79a47.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/subjects/index.vue": {
    "file": "index-d20a837e.mjs",
    "src": "pages/subjects/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Heading-b0b26383.mjs",
      "_Alert-234dff9f.mjs",
      "_Card-60604c66.mjs",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-6c1f0035.mjs",
      "_cookie-4d7aea94.mjs"
    ]
  },
  "layouts/default.vue": {
    "file": "default-ef81dbfa.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-4d7aea94.mjs",
      "_Heading-b0b26383.mjs",
      "_Alert-234dff9f.mjs",
      "_index-09d79a47.mjs"
    ],
    "css": [
      "default.fff22c52.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
