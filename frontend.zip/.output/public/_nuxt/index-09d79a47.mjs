import{D as a}from"./entry-22f3062b.mjs";var r=a.exports;export{r as a};
