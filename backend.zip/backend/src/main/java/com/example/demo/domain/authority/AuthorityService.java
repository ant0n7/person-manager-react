package com.example.demo.domain.authority;

import org.springframework.stereotype.Service;

@Service
public interface AuthorityService {
}
